# 🤖 Mira AI

Mira est une intelligence artificielle personnelle avec mémoire et personnalité, accessible via une interface web.

Elle est conçue pour :
- répondre naturellement comme une vraie personne
- conserver le contexte de conversation
- fonctionner via une architecture sécurisée (frontend + backend)

---

## 🚀 Fonctionnalités

- 💬 Chat en temps réel
- 🧠 Mémoire de conversation
- 🎭 Personnalité (style WhatsApp)
- 🔐 Backend sécurisé (clé API protégée)
- 🌐 Déploiement sur Vercel

---

## 🏗️ Architecture
