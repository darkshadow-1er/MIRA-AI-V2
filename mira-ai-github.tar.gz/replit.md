# MIRA-AI

IA conversationnelle avec personnalité féminine naturelle.

## Stack
- **Backend** : Node.js + Express (ESM)
- **LLM** : Groq API (meta-llama/llama-4-scout-17b-16e-instruct)
- **Recherche web** : DuckDuckGo HTML scraping (gratuit, sans clé)
- **Génération d'images** : Pollinations.ai (gratuit, sans clé)
- **Port** : 5000

## Variables d'environnement
- `GROQ_API_KEY` — clé API Groq (obligatoire)

## Fonctionnalités
- Chat avec mémoire de session (persistée sur disque dans `sessions/`)
- Recherche web automatique via DuckDuckGo (actualités, faits, prix, météo, etc.)
- Génération d'images via Pollinations
- Analyse d'images uploadées (vision)
- Synthèse vocale (TTS navigateur)
- Sessions isolées par utilisateur (sessionId UUID côté client)
- Nettoyage automatique des sessions après 24h

## Structure
```
server.js        — serveur principal
public/
  index.html     — interface utilisateur
sessions/        — mémoire persistante des conversations
```
