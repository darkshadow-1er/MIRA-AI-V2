# Déployer MIRA-AI sur Render (GRATUIT)

## Étapes — 5 minutes maximum

### 1. Mettre le code sur GitHub
- Va sur https://github.com et crée un compte gratuit
- Clique "New repository" → nomme-le `mira-ai` → Public → "Create repository"
- Dans Replit : ouvre le Shell et tape :
  ```
  git init
  git add .
  git commit -m "MIRA-AI"
  git remote add origin https://github.com/TON_USERNAME/mira-ai.git
  git push -u origin main
  ```

### 2. Déployer sur Render
- Va sur https://render.com et crée un compte gratuit (avec GitHub)
- Clique "New +" → "Web Service"
- Connecte ton repo GitHub `mira-ai`
- Render détecte automatiquement le `render.yaml`
- Dans "Environment Variables", ajoute :
  - Key: `GROQ_API_KEY`
  - Value: ta clé Groq
- Clique "Create Web Service"

### 3. Ton lien
Après 2-3 minutes, Render te donne un lien du type :
`https://mira-ai.onrender.com`

C'est ton lien officiel, gratuit, disponible 24h/24 !

---
Note : Sur le plan gratuit de Render, le serveur se met en veille après 15 min d'inactivité,
puis redémarre en ~30 secondes lors du prochain message. Pour éviter ça, tu peux utiliser
un service "uptime" gratuit comme https://uptimerobot.com qui ping ton site toutes les 5 min.
