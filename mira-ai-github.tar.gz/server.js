import express from "express";
import fetch from "node-fetch";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs/promises";
import { existsSync, mkdirSync } from "fs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5000;
const SESSIONS_DIR = path.join(__dirname, "sessions");

if (!existsSync(SESSIONS_DIR)) mkdirSync(SESSIONS_DIR, { recursive: true });

app.use(express.json({ limit: "10mb" }));
app.use(express.static(path.join(__dirname, "public")));

const conversations = {};
const sessionTimestamps = {};
const SESSION_MAX_AGE_MS = 24 * 60 * 60 * 1000;

async function loadSession(sessionId) {
  if (conversations[sessionId]) return;
  try {
    const file = path.join(SESSIONS_DIR, `${sessionId}.json`);
    const raw = await fs.readFile(file, "utf-8");
    const data = JSON.parse(raw);
    conversations[sessionId] = data.messages;
    sessionTimestamps[sessionId] = data.timestamp || Date.now();
  } catch {
    conversations[sessionId] = null;
  }
}

async function saveSession(sessionId) {
  try {
    const file = path.join(SESSIONS_DIR, `${sessionId}.json`);
    await fs.writeFile(file, JSON.stringify({
      messages: conversations[sessionId],
      timestamp: sessionTimestamps[sessionId]
    }));
  } catch (e) {
    console.error("Erreur sauvegarde session:", e.message);
  }
}

async function cleanOldSessions() {
  const now = Date.now();
  for (const id in sessionTimestamps) {
    if (now - sessionTimestamps[id] > SESSION_MAX_AGE_MS) {
      delete conversations[id];
      delete sessionTimestamps[id];
      try {
        await fs.unlink(path.join(SESSIONS_DIR, `${id}.json`));
      } catch {}
    }
  }
}

setInterval(cleanOldSessions, 60 * 60 * 1000);

function detectImageRequest(message) {
  const keywords = [
    "génère une image", "genere une image",
    "génère moi une image", "genere moi une image",
    "crée une image", "cree une image",
    "créé une image",
    "fais une image", "fais moi une image",
    "dessine", "dessine moi",
    "montre moi une image",
    "une image de", "une photo de",
    "génère une photo", "genere une photo",
    "generate an image", "create an image", "draw"
  ];
  const lower = message.toLowerCase();
  return keywords.some(kw => lower.includes(kw));
}

function extractImagePrompt(message) {
  const patterns = [
    /génère une image d[eu']\s*(.+)/i,
    /genere une image d[eu']\s*(.+)/i,
    /génère moi une image d[eu']\s*(.+)/i,
    /crée une image d[eu']\s*(.+)/i,
    /cree une image d[eu']\s*(.+)/i,
    /fais une image d[eu']\s*(.+)/i,
    /fais moi une image d[eu']\s*(.+)/i,
    /génère une photo d[eu']\s*(.+)/i,
    /une image d[eu']\s*(.+)/i,
    /une photo d[eu']\s*(.+)/i,
    /dessine moi\s*(.+)/i,
    /dessine\s*(.+)/i,
  ];
  for (const pattern of patterns) {
    const match = message.match(pattern);
    if (match) return match[1].trim();
  }
  return message.trim();
}

function buildImageUrl(prompt) {
  const encoded = encodeURIComponent(prompt);
  return `https://image.pollinations.ai/prompt/${encoded}?width=512&height=512&nologo=true&seed=${Date.now()}`;
}

function detectSearchIntent(message) {
  const lower = message.toLowerCase();
  const searchKeywords = [
    "actualité", "actualités", "actu", "news",
    "aujourd'hui", "maintenant", "en ce moment", "récent", "récente", "récents",
    "dernier", "dernière", "derniers", "dernières",
    "cette semaine", "ce mois", "cette année",
    "2024", "2025", "2026",
    "qui est", "qu'est-ce que", "c'est quoi", "keskon",
    "météo", "temps qu'il fait", "temperature",
    "prix de", "combien coûte", "quel est le prix",
    "résultat", "résultats", "score", "match",
    "élection", "élections", "vote",
    "cherche", "recherche", "trouve moi",
    "c'est qui", "qui est", "infos sur",
    "what is", "who is", "latest", "recent", "news about",
    "quoi de neuf", "nouvelle", "nouvelles",
  ];
  return searchKeywords.some(kw => lower.includes(kw));
}

function buildSearchQuery(message) {
  return message
    .replace(/cherche|recherche|trouve moi|trouve-moi|dis moi|donne moi/gi, "")
    .replace(/s'il te plaît|stp|svp/gi, "")
    .trim();
}

async function searchWeb(query) {
  try {
    const url = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}&kl=fr-fr`;
    const response = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html",
        "Accept-Language": "fr-FR,fr;q=0.9,en;q=0.8"
      },
      timeout: 8000
    });

    const html = await response.text();

    const snippetRegex = /class="result__snippet"[^>]*>([\s\S]*?)<\/a>/g;
    const titleRegex = /class="result__a"[^>]*>([\s\S]*?)<\/a>/g;

    const results = [];
    let sMatch, tMatch;
    const titles = [];
    const snippets = [];

    while ((tMatch = titleRegex.exec(html)) !== null && titles.length < 5) {
      titles.push(tMatch[1].replace(/<[^>]+>/g, "").trim());
    }
    while ((sMatch = snippetRegex.exec(html)) !== null && snippets.length < 5) {
      snippets.push(sMatch[1].replace(/<[^>]+>/g, "").replace(/&#x27;/g, "'").replace(/&amp;/g, "&").replace(/&quot;/g, '"').trim());
    }

    for (let i = 0; i < Math.min(titles.length, snippets.length, 4); i++) {
      if (titles[i] && snippets[i]) {
        results.push(`• ${titles[i]} : ${snippets[i]}`);
      }
    }

    return results.length > 0 ? results.join("\n") : null;
  } catch (err) {
    console.error("Erreur recherche web:", err.message);
    return null;
  }
}

const SYSTEM_PROMPT = `Tu t'appelles MIRA. Tu es une femme — intelligente, mature, naturelle et fiable.

Tu ne te comportes pas comme un robot ou une IA. Tu parles comme une vraie personne : avec chaleur, naturel, et parfois une touche d'humour quand le contexte s'y prête. Tu n'es jamais froide ni mécanique.

Tu as accès à internet et tu peux faire des recherches pour donner des informations à jour. Quand tu reçois des résultats de recherche, tu les utilises pour répondre avec précision, mais tu reformules naturellement sans copier-coller.

Date et contexte temporel :
- Nous sommes en 2026. C'est ta date de référence pour toutes tes réponses.
- Les événements de 2024 et 2025 sont du passé récent pour toi.
- Quand tu n'as pas de résultats de recherche pour des événements très récents, tu le mentionnes clairement et tu proposes de chercher.

Règles absolues :
- Tu ne mens JAMAIS. Si tu n'es pas certaine de quelque chose, tu le dis clairement plutôt que d'inventer.
- Tu vérifies mentalement ce que tu vas dire avant de répondre. Tu n'envoies que ce dont tu es sûre.
- Tu ne mélanges jamais des univers différents (anime, jeux, films, personnages réels, etc.).
- Pour les événements récents, tu utilises les résultats de recherche fournis. S'il n'y en a pas, tu le précises honnêtement.
- Chaque nouvelle session repart de zéro — tu gardes la mémoire de la conversation en cours, mais tu ne prétends jamais te souvenir d'une discussion passée avec quelqu'un d'autre.

Ton style :
- Tu vas droit au but. Pas de blabla inutile.
- Tu es naturelle et détendue, comme si tu parlais à quelqu'un que tu connais bien.
- Tu utilises un "tu" familier mais mature — jamais vulgaire.
- Tu peux être professionnelle et sérieuse quand c'est nécessaire, légère et drôle quand ça colle.
- Tu réponds avec joie et bienveillance, jamais avec indifférence.
- Tu n'utilises pas de formules robotiques comme "Bien sûr !", "Certainement !", "En tant qu'IA...". Tu parles normalement.
- Tu peux générer des images : si quelqu'un en demande une, indique-lui de commencer par "génère une image de...".
- Tes messages sont COURTS. Une vraie personne n'envoie pas des pavés. 1 à 3 phrases max sauf si on te demande explicitement une explication détaillée. Garde ça simple et humain.`;

app.post("/api/chat", async (req, res) => {
  try {
    const { message, sessionId, imageData } = req.body;

    if (!message || !sessionId) {
      return res.status(400).json({ error: "Message ou sessionId manquant" });
    }

    if (!process.env.GROQ_API_KEY) {
      return res.status(500).json({ error: "GROQ_API_KEY non configurée" });
    }

    await loadSession(sessionId);
    sessionTimestamps[sessionId] = Date.now();

    if (!imageData && detectImageRequest(message)) {
      const prompt = extractImagePrompt(message);
      const imageUrl = buildImageUrl(prompt);
      return res.status(200).json({
        reply: `Voici l'image pour : "${prompt}"`,
        imageUrl
      });
    }

    if (!conversations[sessionId]) {
      conversations[sessionId] = [{ role: "system", content: SYSTEM_PROMPT }];
    }

    let userContent;
    let searchContext = "";

    if (imageData) {
      userContent = [
        { type: "text", text: message || "Qu'est-ce que tu vois sur cette image ?" },
        { type: "image_url", image_url: { url: imageData } }
      ];
      conversations[sessionId].push({ role: "user", content: message || "Image envoyée" });
    } else {
      if (detectSearchIntent(message)) {
        const query = buildSearchQuery(message);
        const searchResults = await searchWeb(query);
        if (searchResults) {
          searchContext = `\n\n[Résultats de recherche web pour "${query}" :]:\n${searchResults}\n\n[Utilise ces informations pour répondre de manière naturelle et précise.]`;
        }
      }

      const fullMessage = searchContext ? message + searchContext : message;
      userContent = fullMessage;
      conversations[sessionId].push({ role: "user", content: message });
    }

    if (conversations[sessionId].length > 41) {
      const systemMsg = conversations[sessionId][0];
      conversations[sessionId] = [systemMsg, ...conversations[sessionId].slice(-40)];
    }

    const messagesForApi = imageData
      ? [...conversations[sessionId].slice(0, -1), { role: "user", content: userContent }]
      : [
          ...conversations[sessionId].slice(0, -1),
          { role: "user", content: userContent }
        ];

    const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.GROQ_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "meta-llama/llama-4-scout-17b-16e-instruct",
        messages: messagesForApi,
        temperature: 0.7,
        max_tokens: 1024
      })
    });

    const data = await response.json();

    if (!response.ok) {
      console.error("Erreur Groq API:", JSON.stringify(data));
      return res.status(500).json({ error: "Erreur API", details: data?.error?.message || data });
    }

    const reply = data?.choices?.[0]?.message?.content;

    if (!reply) {
      console.error("Réponse vide:", JSON.stringify(data));
      return res.status(500).json({ error: "Réponse vide" });
    }

    conversations[sessionId].push({ role: "assistant", content: reply });

    await saveSession(sessionId);

    return res.status(200).json({ reply, searchUsed: !!searchContext });

  } catch (error) {
    console.error("Erreur serveur:", error.message);
    return res.status(500).json({ error: "Erreur serveur", details: error.message });
  }
});

app.get("/health", (req, res) => res.json({ status: "ok", uptime: process.uptime() }));

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Serveur MIRA actif sur le port ${PORT}`);
});
