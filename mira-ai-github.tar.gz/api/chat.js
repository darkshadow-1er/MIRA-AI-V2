import fetch from "node-fetch";

// ✅ mémoire par session
const conversations = {};

export default async function handler(req, res) {
  try {
    if (req.method !== "POST") {
      return res.status(405).json({ error: "Method not allowed" });
    }

    const { message, sessionId } = req.body;

    if (!message || !sessionId) {
      return res.status(400).json({ error: "Message ou sessionId manquant" });
    }

    // ✅ Initialisation de la conversation pour chaque utilisateur
    if (!conversations[sessionId]) {
      conversations[sessionId] = [
        {
          role: "system",
          content: `Tu es MIRA, une assistante intelligente, fiable et précise.

Règles strictes :
- Tu ne dois jamais inventer d'informations.
- Si tu n'es pas certaine, dis-le clairement.
- Tu évites les erreurs et les approximations.
- Tu ne mélanges jamais des univers (anime, jeux, etc.).
- Tu privilégies toujours des faits corrects.

Style :
- Réponses claires et directes
- Ton calme, professionnel et humain
- Réponses concises

Tu es fiable et sérieuse.`
        }
      ];
    }

    // ✅ Ajouter message utilisateur
    conversations[sessionId].push({
      role: "user",
      content: message
    });

    // ✅ Limiter la mémoire (important pour éviter surcharge)
    if (conversations[sessionId].length > 20) {
      conversations[sessionId] = conversations[sessionId].slice(-20);
    }

    const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.GROQ_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "llama-3.1-8b-instant",
        messages: conversations[sessionId]
      })
    });

    const data = await response.json();

    let reply = data?.choices?.[0]?.message?.content;

    if (!reply) {
      return res.status(500).json({
        error: "Réponse vide",
        details: data
      });
    }

    // ❌ correction trop spécifique → à éviter (on améliore plus tard)
    // (on garde simple pour éviter les bugs)

    // ✅ Ajouter réponse IA à la mémoire
    conversations[sessionId].push({
      role: "assistant",
      content: reply
    });

    return res.status(200).json({ reply });

  } catch (error) {
    return res.status(500).json({
      error: "Erreur serveur",
      details: error.message
    });
  }
        }
